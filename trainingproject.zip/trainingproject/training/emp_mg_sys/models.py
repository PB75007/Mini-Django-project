from django.db import models
from email.policy import default
from unittest.util import _MAX_LENGTH

# Create your models here.
class Loginadmin(models.Model):
    username = models.CharField(max_length = 50)
    password = models.CharField(max_length = 50,primary_key = True)

class Timesheets_mng(models.Model):
    empID = models.IntegerField(primary_key = True)
    day = models.CharField(max_length=50)
    date = models.DateField()
    timein = models.CharField(max_length=50)
    timeout = models.CharField(max_length=50)
    totalhours = models.IntegerField()
    deptID = models.CharField(max_length=50)

class Employee(models.Model):
    name = models.CharField(max_length=40)
    address = models.CharField(max_length=120,default="Zensar")
    empID = models.IntegerField(primary_key = True)

class AppraisalMngSystem(models.Model):
    emp_ID = models.CharField(max_length = 50,primary_key = True)
    jobknowledge = models.CharField(max_length = 50)
    workquality = models.CharField(max_length = 50)
    techskills  = models.CharField(max_length = 50)
    salary = models.IntegerField()
    appraise = models.IntegerField()
    




